import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class database {

    static Connection con;

    static void connect() {
        try {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/IntraRoomDB", "zakih", "zakih");
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    static ResultSet getAllInterativeRooms() {
        
            connect();
        
        try {
            String query = "Select * from interactiverooms";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            return rs;
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    static boolean addSection(String name, int capacity) {
        
        connect();
        F7_addnewRoom addRoom = new F7_addnewRoom();
        int idRoom = Integer.parseInt(addRoom.IdRoomTxt.getText());
        String RoomName = addRoom.RNameTxt.getText();
        
        try {
            String query = "insert into interactiverooms ( roomId , sectionName, sectionCapacity ) Values('"+idRoom+"','"+-1+"','" + name + "','" + capacity + "')";
            Statement st = con.createStatement();
            return st.executeUpdate(query) > 0;
        } catch (SQLException e) {
            System.out.println(e);
        }
        return false;
    }
}